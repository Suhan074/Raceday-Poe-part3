using Microsoft.AspNetCore.Mvc;
using RaceDayMVC.Models.Auth;
using RaceDayMVC.Services;
using System.Threading.Tasks;

namespace RaceDayMVC.Controllers
{
    public class AccountController : Controller
    {
        private readonly IApiService _apiService;

        public AccountController(IApiService apiService)
        {
            _apiService = apiService;
        }

        [HttpGet]
        public IActionResult Login()
        {
            if (HttpContext.Session.GetString("JwtToken") != null)
                return RedirectToAction("Index", "Home");
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            var response = await _apiService.PostAsync<AuthResponseViewModel>("auth/login", model);
            if (response != null && !string.IsNullOrEmpty(response.Token))
            {
                // Save token and user info to session
                HttpContext.Session.SetString("JwtToken", response.Token);
                HttpContext.Session.SetString("UserRole", response.User.Role);
                HttpContext.Session.SetString("UserName", response.User.FullName);
                HttpContext.Session.SetInt32("UserId", response.User.UserID);

                if (response.User.Role == "Organiser")
                    return RedirectToAction("Index", "Events"); // Organiser Dashboard
                else
                    return RedirectToAction("Index", "Home"); // Participant Dashboard
            }

            ModelState.AddModelError("", "Invalid email or password.");
            return View(model);
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            var response = await _apiService.PostAsync<AuthResponseViewModel>("auth/register", model);
            if (response != null && !string.IsNullOrEmpty(response.Token))
            {
                HttpContext.Session.SetString("JwtToken", response.Token);
                HttpContext.Session.SetString("UserRole", response.User.Role);
                HttpContext.Session.SetString("UserName", response.User.FullName);
                HttpContext.Session.SetInt32("UserId", response.User.UserID);

                return RedirectToAction("Index", "Home");
            }

            ModelState.AddModelError("", "Registration failed. Email might already exist.");
            return View(model);
        }

        [HttpPost]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login", "Account");
        }
    }
}