using Microsoft.AspNetCore.Mvc;
using RaceDayMVC.Models.Enrolments;
using RaceDayMVC.Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace RaceDayMVC.Controllers
{
    public class EnrolmentsController : Controller
    {
        private readonly IApiService _apiService;

        public EnrolmentsController(IApiService apiService)
        {
            _apiService = apiService;
        }

        // Participant: Enrol in a category
        [HttpPost]
        public async Task<IActionResult> Enrol(int categoryId)
        {
            if (HttpContext.Session.GetString("UserRole") != "Participant")
                return RedirectToAction("Login", "Account");

            var result = await _apiService.PostAsync<object>("enrolments", new { CategoryId = categoryId });
            TempData["Message"] = result != null ? "Successfully enrolled!" : "Failed to enrol.";
            
            return RedirectToAction("MyEnrolments");
        }

        // Participant: View own enrolments
        public async Task<IActionResult> MyEnrolments()
        {
            if (HttpContext.Session.GetString("UserRole") != "Participant")
                return RedirectToAction("Login", "Account");

            var enrolments = await _apiService.GetAsync<List<MyEnrolmentViewModel>>("enrolments/participant");
            return View(enrolments ?? new List<MyEnrolmentViewModel>());
        }

        // Organiser: View enrolments for a specific event
        public async Task<IActionResult> EventEnrolments(int eventId)
        {
            if (HttpContext.Session.GetString("UserRole") != "Organiser")
                return RedirectToAction("Login", "Account");

            var enrolments = await _apiService.GetAsync<List<EventEnrolmentViewModel>>($"enrolments/event/{eventId}");
            ViewBag.EventId = eventId;
            return View(enrolments ?? new List<EventEnrolmentViewModel>());
        }

        // Organiser: Confirm an enrolment
        [HttpPost]
        public async Task<IActionResult> UpdateStatus(int id, int eventId, string status)
        {
            await _apiService.PutAsync<object>($"enrolments/{id}/status", new { Status = status });
            return RedirectToAction("EventEnrolments", new { eventId });
        }
    }
}