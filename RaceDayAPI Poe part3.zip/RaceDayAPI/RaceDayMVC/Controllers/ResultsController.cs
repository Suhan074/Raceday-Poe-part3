using Microsoft.AspNetCore.Mvc;
using RaceDayMVC.Models.Results;
using RaceDayMVC.Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace RaceDayMVC.Controllers
{
    public class ResultsController : Controller
    {
        private readonly IApiService _apiService;

        public ResultsController(IApiService apiService)
        {
            _apiService = apiService;
        }

        // Participant: View own results
        public async Task<IActionResult> MyResults()
        {
            if (HttpContext.Session.GetString("UserRole") != "Participant")
                return RedirectToAction("Login", "Account");

            var results = await _apiService.GetAsync<List<MyResultViewModel>>("results/participant");
            return View(results ?? new List<MyResultViewModel>());
        }

        // Organiser: View results of an event
        public async Task<IActionResult> EventResults(int eventId)
        {
            if (HttpContext.Session.GetString("UserRole") != "Organiser")
                return RedirectToAction("Login", "Account");

            var results = await _apiService.GetAsync<List<EventResultViewModel>>($"results/event/{eventId}");
            ViewBag.EventId = eventId;
            return View(results ?? new List<EventResultViewModel>());
        }

        // Organiser: Form to enter result
        [HttpGet]
        public IActionResult EnterResult(int enrolmentId, int eventId)
        {
            if (HttpContext.Session.GetString("UserRole") != "Organiser") return RedirectToAction("Login");
            ViewBag.EventId = eventId;
            return View(new CreateResultViewModel { EnrolmentId = enrolmentId });
        }

        // Organiser: Submit result
        [HttpPost]
        public async Task<IActionResult> EnterResult(CreateResultViewModel model, int eventId)
        {
            if (!ModelState.IsValid) return View(model);

            var result = await _apiService.PostAsync<object>("results", model);
            if (result != null) return RedirectToAction("EventResults", new { eventId });

            ModelState.AddModelError("", "Failed to save result.");
            return View(model);
        }
    }
}