using Microsoft.AspNetCore.Mvc;
using RaceDayMVC.Services;
using System.Threading.Tasks;

namespace RaceDayMVC.Controllers
{
    public class ProfileController : Controller
    {
        private readonly IApiService _apiService;

        public ProfileController(IApiService apiService)
        {
            _apiService = apiService;
        }

        public async Task<IActionResult> Index()
        {
            if (HttpContext.Session.GetString("JwtToken") == null)
                return RedirectToAction("Login", "Account");

            var profile = await _apiService.GetAsync<RaceDayMVC.Models.Users.UserProfileViewModel>("users/profile");
            if (profile == null) return RedirectToAction("Login", "Account");

            return View(profile);
        }

        [HttpPost]
        public async Task<IActionResult> UploadProfilePicture(IFormFile file)
        {
            if (file != null && file.Length > 0)
            {
                await _apiService.UploadFileAsync("users/upload-profile-picture", file);
                TempData["Message"] = "Profile picture updated!";
            }
            return RedirectToAction("Index");
        }
    }
}