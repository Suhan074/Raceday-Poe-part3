using Microsoft.AspNetCore.Mvc;
using RaceDayMVC.Models.Events;
using RaceDayMVC.Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace RaceDayMVC.Controllers
{
    public class HomeController : Controller
    {
        private readonly IApiService _apiService;

        public HomeController(IApiService apiService)
        {
            _apiService = apiService;
        }

        public async Task<IActionResult> Index(string search)
        {
            var url = "events";
            if (!string.IsNullOrEmpty(search)) url += $"?search={search}";

            var events = await _apiService.GetAsync<List<EventListViewModel>>(url);
            return View(events ?? new List<EventListViewModel>());
        }

        [HttpGet]
        public async Task<IActionResult> Details(int id)
        {
            var ev = await _apiService.GetAsync<EventDetailViewModel>($"events/{id}");
            if (ev == null) return NotFound();
            return View(ev);
        }
    }
}