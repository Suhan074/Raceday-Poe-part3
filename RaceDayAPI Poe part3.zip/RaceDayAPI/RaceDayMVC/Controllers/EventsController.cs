using Microsoft.AspNetCore.Mvc;
using RaceDayMVC.Models.Events;
using RaceDayMVC.Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace RaceDayMVC.Controllers
{
    public class EventsController : Controller
    {
        private readonly IApiService _apiService;

        public EventsController(IApiService apiService)
        {
            _apiService = apiService;
        }

        // Organiser Dashboard
        public async Task<IActionResult> Index()
        {
            if (HttpContext.Session.GetString("UserRole") != "Organiser")
                return RedirectToAction("Login", "Account");

            var events = await _apiService.GetAsync<List<EventListViewModel>>("events");
            return View(events ?? new List<EventListViewModel>());
        }

        [HttpGet]
        public IActionResult Create()
        {
            if (HttpContext.Session.GetString("UserRole") != "Organiser") return RedirectToAction("Login");
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(CreateEventViewModel model, IFormFile banner)
        {
            if (!ModelState.IsValid) return View(model);

            var createdEvent = await _apiService.PostAsync<EventDetailViewModel>("events", model);
            if (createdEvent != null)
            {
                // If there is a file, upload it
                if (banner != null && banner.Length > 0)
                {
                    await _apiService.UploadFileAsync($"events/{createdEvent.EventID}/upload-banner", banner);
                }
                return RedirectToAction("Index");
            }

            ModelState.AddModelError("", "Failed to create event.");
            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> ManageCategories(int id)
        {
            if (HttpContext.Session.GetString("UserRole") != "Organiser") return RedirectToAction("Login");
            var ev = await _apiService.GetAsync<EventDetailViewModel>($"events/{id}");
            return View(ev); 
        }

        [HttpPost]
        public async Task<IActionResult> AddCategory(int eventId, CreateCategoryViewModel model)
        {
            if (!ModelState.IsValid) return RedirectToAction("ManageCategories", new { id = eventId });

            await _apiService.PostAsync<object>($"events/{eventId}/categories", model);
            return RedirectToAction("ManageCategories", new { id = eventId });
        }
    }
}