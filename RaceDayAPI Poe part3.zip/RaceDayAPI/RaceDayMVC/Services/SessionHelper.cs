using Microsoft.AspNetCore.Http;

namespace RaceDayMVC.Services
{
    /// <summary>
    /// Helper class to manage user session data easily
    /// </summary>
    public static class SessionHelper
    {
        // Session Keys
        private const string TokenKey = "JwtToken";
        private const string UserIdKey = "UserId";
        private const string UserRoleKey = "UserRole";
        private const string UserNameKey = "UserName";
        private const string ProfileImageKey = "ProfileImageUrl";

        /// <summary>
        /// Save user details to session after successful login
        /// </summary>
        public static void SetUserSession(this ISession session, string token, int userId, string userName, string role, string? profileImageUrl = null)
        {
            session.SetString(TokenKey, token);
            session.SetInt32(UserIdKey, userId);
            session.SetString(UserNameKey, userName);
            session.SetString(UserRoleKey, role);
            
            if (!string.IsNullOrEmpty(profileImageUrl))
            {
                session.SetString(ProfileImageKey, profileImageUrl);
            }
        }

        /// <summary>
        /// Get the JWT Token
        /// </summary>
        public static string? GetToken(this ISession session)
        {
            return session.GetString(TokenKey);
        }

        /// <summary>
        /// Get the logged-in User's ID
        /// </summary>
        public static int? GetUserId(this ISession session)
        {
            return session.GetInt32(UserIdKey);
        }

        /// <summary>
        /// Get the logged-in User's Role (Organiser or Participant)
        /// </summary>
        public static string? GetRole(this ISession session)
        {
            return session.GetString(UserRoleKey);
        }

        /// <summary>
        /// Get the logged-in User's Full Name
        /// </summary>
        public static string? GetUserName(this ISession session)
        {
            return session.GetString(UserNameKey);
        }

        /// <summary>
        /// Get the logged-in User's Profile Image URL
        /// </summary>
        public static string? GetProfileImage(this ISession session)
        {
            return session.GetString(ProfileImageKey);
        }

        /// <summary>
        /// Check if a user is currently logged in
        /// </summary>
        public static bool IsLoggedIn(this ISession session)
        {
            return !string.IsNullOrEmpty(session.GetToken());
        }

        /// <summary>
        /// Check if the logged-in user is an Organiser
        /// </summary>
        public static bool IsOrganiser(this ISession session)
        {
            return session.GetRole() == "Organiser";
        }

        /// <summary>
        /// Check if the logged-in user is a Participant
        /// </summary>
        public static bool IsParticipant(this ISession session)
        {
            return session.GetRole() == "Participant";
        }

        /// <summary>
        /// Clear all session data (Logout)
        /// </summary>
        public static void ClearUserSession(this ISession session)
        {
            session.Clear();
        }
    }
}