namespace RaceDayMVC.Models.Auth
{
    public class AuthResponseViewModel
    {
        public string Token { get; set; } = string.Empty;
        public UserInfoViewModel User { get; set; } = new UserInfoViewModel();
    }

    public class UserInfoViewModel
    {
        public int UserID { get; set; }
        public string Email { get; set; } = string.Empty;
        public string FullName { get; set; } = string.Empty;
        public string Role { get; set; } = string.Empty;
        public string? ProfileImageUrl { get; set; }
    }
}