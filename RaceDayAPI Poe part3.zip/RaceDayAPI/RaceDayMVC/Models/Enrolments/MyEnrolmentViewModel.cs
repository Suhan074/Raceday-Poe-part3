namespace RaceDayMVC.Models.Enrolments
{
    public class MyEnrolmentViewModel
    {
        public int EnrolmentID { get; set; }
        public string EventName { get; set; } = string.Empty;
        public DateTime EventDate { get; set; }
        public string CategoryName { get; set; } = string.Empty;
        public DateTime EnrolmentDate { get; set; }
        public string Status { get; set; } = string.Empty; // Pending, Confirmed, Cancelled
        public string PaymentStatus { get; set; } = string.Empty;
        public bool HasResult { get; set; }
    }
}