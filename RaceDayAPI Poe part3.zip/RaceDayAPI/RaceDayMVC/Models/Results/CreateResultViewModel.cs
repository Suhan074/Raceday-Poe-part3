using System.ComponentModel.DataAnnotations;

namespace RaceDayMVC.Models.Results
{
    public class CreateResultViewModel
    {
        [Required]
        public int EnrolmentId { get; set; }

        public TimeSpan? FinishTime { get; set; }

        [Range(1, 100000, ErrorMessage = "Position must be a positive number")]
        public int? Position { get; set; }

        [Required(ErrorMessage = "Status is required")]
        public string Status { get; set; } = "Finished"; // Finished, DNS, DNF, Disqualified

        public string? Notes { get; set; }
    }
}