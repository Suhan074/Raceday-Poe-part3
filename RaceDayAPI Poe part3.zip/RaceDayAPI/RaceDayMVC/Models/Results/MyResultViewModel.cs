namespace RaceDayMVC.Models.Results
{
    public class MyResultViewModel
    {
        public int ResultID { get; set; }
        public string EventName { get; set; } = string.Empty;
        public string CategoryName { get; set; } = string.Empty;
        public TimeSpan? FinishTime { get; set; }
        public int? Position { get; set; }
        public string Status { get; set; } = string.Empty; // Finished, DNS, DNF
        public string? Notes { get; set; }
    }
}