namespace RaceDayMVC.Models.Results
{
    public class EventResultViewModel
    {
        public int ResultID { get; set; }
        public string ParticipantName { get; set; } = string.Empty;
        public string CategoryName { get; set; } = string.Empty;
        public TimeSpan? FinishTime { get; set; }
        public int? Position { get; set; }
        public string Status { get; set; } = string.Empty;
        public string? Notes { get; set; }
    }
}