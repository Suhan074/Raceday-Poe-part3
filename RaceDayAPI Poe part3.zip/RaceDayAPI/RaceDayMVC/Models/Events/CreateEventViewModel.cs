using System.ComponentModel.DataAnnotations;

namespace RaceDayMVC.Models.Events
{
    public class CreateEventViewModel
    {
        [Required(ErrorMessage = "Event name is required")]
        public string EventName { get; set; } = string.Empty;

        public string? Description { get; set; }

        [Required(ErrorMessage = "Event date is required")]
        [DataType(DataType.DateTime)]
        public DateTime EventDate { get; set; } = DateTime.Now.AddDays(7);

        [Required(ErrorMessage = "Location is required")]
        public string Location { get; set; } = string.Empty;

        [Required(ErrorMessage = "Distance is required")]
        public string Distance { get; set; } = string.Empty;

        [Required(ErrorMessage = "Event type is required")]
        public string EventType { get; set; } = "Run"; // Run, Walk, Cycle

        [Required(ErrorMessage = "Max participants is required")]
        [Range(1, 100000, ErrorMessage = "Must be greater than 0")]
        public int MaxParticipants { get; set; } = 100;

        public string? Status { get; set; } = "Upcoming";
    }
}