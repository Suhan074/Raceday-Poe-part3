namespace RaceDayMVC.Models.Categories
{
    public class CategoryViewModel
    {
        public int CategoryID { get; set; }
        public int EventID { get; set; }
        public string EventName { get; set; } = string.Empty;
        public string CategoryName { get; set; } = string.Empty;
        public string? Description { get; set; }
        public int? MinAge { get; set; }
        public int? MaxAge { get; set; }
        public string GenderRestriction { get; set; } = string.Empty;
        public int EnrolmentCount { get; set; }
    }
}