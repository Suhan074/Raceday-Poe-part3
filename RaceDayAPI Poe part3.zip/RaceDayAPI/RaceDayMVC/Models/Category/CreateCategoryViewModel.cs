using System.ComponentModel.DataAnnotations;

namespace RaceDayMVC.Models.Categories
{
    public class CreateCategoryViewModel
    {
        [Required(ErrorMessage = "Category name is required")]
        public string CategoryName { get; set; } = string.Empty;

        public string? Description { get; set; }

        [Range(0, 120, ErrorMessage = "Invalid age")]
        public int? MinAge { get; set; }

        [Range(0, 120, ErrorMessage = "Invalid age")]
        public int? MaxAge { get; set; }

        public string GenderRestriction { get; set; } = "None"; // None, Male, Female
    }
}