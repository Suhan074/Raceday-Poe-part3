using Microsoft.EntityFrameworkCore;
using RaceDayAPI.Data;

namespace RaceDayAPI.Tests.Helpers
{
    /// <summary>
    /// Factory to create a fresh in-memory database for each test
    /// </summary>
    public static class TestDbContextFactory
    {
        public static RaceDayDbContext Create()
        {
            var options = new DbContextOptionsBuilder<RaceDayDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            var context = new RaceDayDbContext(options);
            context.Database.EnsureCreated();
            return context;
        }

        public static void Destroy(RaceDayDbContext context)
        {
            context.Database.EnsureDeleted();
            context.Dispose();
        }
    }
}