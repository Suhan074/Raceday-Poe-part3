using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using RaceDayAPI.Controllers;
using RaceDayAPI.DTOs.Enrolments;
using RaceDayAPI.Helpers;
using RaceDayAPI.Services.Implementations;
using RaceDayAPI.Tests.Helpers;
using Xunit;

namespace RaceDayAPI.Tests.Controllers
{
    public class EnrolmentsControllerTests
    {
        [Fact]
        public async Task Enrol_AsParticipant_Returns201()
        {
            // Arrange
            using var context = TestDbContextFactory.Create();
            TestDataSeeder.SeedAll(context);
            var service = new EnrolmentService(context);
            var controller = new EnrolmentsController(service);
            SetUser(controller, userId: 2, role: RoleConstants.Participant);

            var dto = new CreateEnrolmentDto { CategoryId = 1 };

            // Act
            var result = await controller.Enrol(dto);

            // Assert
            result.Should().BeOfType<CreatedAtActionResult>();
        }

        [Fact]
        public async Task Enrol_DuplicateEnrolment_Returns409()
        {
            // Arrange
            using var context = TestDbContextFactory.Create();
            TestDataSeeder.SeedAll(context);
            var service = new EnrolmentService(context);
            var controller = new EnrolmentsController(service);
            SetUser(controller, userId: 2, role: RoleConstants.Participant);

            var dto = new CreateEnrolmentDto { CategoryId = 1 };
            await controller.Enrol(dto); // First time

            // Act - Second time
            var result = await controller.Enrol(dto);

            // Assert
            result.Should().BeOfType<ConflictObjectResult>();
        }

        [Fact]
        public async Task GetMyEnrolments_Returns200()
        {
            // Arrange
            using var context = TestDbContextFactory.Create();
            TestDataSeeder.SeedAll(context);
            var service = new EnrolmentService(context);
            var controller = new EnrolmentsController(service);
            SetUser(controller, userId: 2, role: RoleConstants.Participant);

            await controller.Enrol(new CreateEnrolmentDto { CategoryId = 1 });

            // Act
            var result = await controller.GetMyEnrolments();

            // Assert
            result.Should().BeOfType<OkObjectResult>();
        }

        private static void SetUser(ControllerBase controller, int userId, string role)
        {
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, userId.ToString()),
                new Claim(ClaimTypes.Role, role)
            };
            var identity = new ClaimsIdentity(claims);
            controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext
                {
                    User = new ClaimsPrincipal(identity)
                }
            };
        }
    }
}