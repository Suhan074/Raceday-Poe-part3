using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using RaceDayAPI.Controllers;
using RaceDayAPI.DTOs.Enrolments;
using RaceDayAPI.DTOs.Results;
using RaceDayAPI.Helpers;
using RaceDayAPI.Services.Implementations;
using RaceDayAPI.Tests.Helpers;
using Xunit;

namespace RaceDayAPI.Tests.Controllers
{
    public class ResultsControllerTests
    {
        [Fact]
        public async Task AddResult_AsOrganiser_Returns201()
        {
            // Arrange
            using var context = TestDbContextFactory.Create();
            TestDataSeeder.SeedAll(context);
            var enrolmentService = new EnrolmentService(context);
            var enrolment = await enrolmentService.CreateEnrolmentAsync(2, new CreateEnrolmentDto { CategoryId = 1 });

            var resultService = new ResultService(context);
            var controller = new ResultsController(resultService);
            SetUser(controller, userId: 1, role: RoleConstants.Organiser);

            var dto = new CreateResultDto
            {
                EnrolmentId = enrolment.EnrolmentID,
                FinishTime = TimeSpan.FromHours(1),
                Position = 1,
                Status = "Finished",
                Notes = "Great run"
            };

            // Act
            var result = await controller.AddResult(dto);

            // Assert
            result.Should().BeOfType<CreatedAtActionResult>();
        }

        [Fact]
        public async Task GetMyResults_AsParticipant_Returns200()
        {
            // Arrange
            using var context = TestDbContextFactory.Create();
            TestDataSeeder.SeedAll(context);
            var enrolmentService = new EnrolmentService(context);
            var enrolment = await enrolmentService.CreateEnrolmentAsync(2, new CreateEnrolmentDto { CategoryId = 1 });

            var resultService = new ResultService(context);
            await resultService.AddResultAsync(1, new CreateResultDto
            {
                EnrolmentId = enrolment.EnrolmentID,
                FinishTime = TimeSpan.FromHours(1),
                Position = 1,
                Status = "Finished"
            });

            var controller = new ResultsController(resultService);
            SetUser(controller, userId: 2, role: RoleConstants.Participant);

            // Act
            var result = await controller.GetMyResults();

            // Assert
            result.Should().BeOfType<OkObjectResult>();
        }

        [Fact]
        public async Task GetLeaderboard_Returns200WithList()
        {
            // Arrange
            using var context = TestDbContextFactory.Create();
            TestDataSeeder.SeedAll(context);
            var enrolmentService = new EnrolmentService(context);
            var enrolment = await enrolmentService.CreateEnrolmentAsync(2, new CreateEnrolmentDto { CategoryId = 1 });

            var resultService = new ResultService(context);
            await resultService.AddResultAsync(1, new CreateResultDto
            {
                EnrolmentId = enrolment.EnrolmentID,
                FinishTime = TimeSpan.FromHours(1),
                Position = 1,
                Status = "Finished"
            });

            var controller = new ResultsController(resultService);

            // Act
            var result = await controller.GetLeaderboard(1);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
        }

        private static void SetUser(ControllerBase controller, int userId, string role)
        {
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, userId.ToString()),
                new Claim(ClaimTypes.Role, role)
            };
            var identity = new ClaimsIdentity(claims);
            controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext
                {
                    User = new ClaimsPrincipal(identity)
                }
            };
        }
    }
}