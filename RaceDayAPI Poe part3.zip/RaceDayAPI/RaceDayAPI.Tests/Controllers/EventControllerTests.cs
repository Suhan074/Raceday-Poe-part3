using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using RaceDayAPI.Controllers;
using RaceDayAPI.DTOs.Events;
using RaceDayAPI.Helpers;
using RaceDayAPI.Services.Implementations;
using RaceDayAPI.Tests.Helpers;
using Xunit;

namespace RaceDayAPI.Tests.Controllers
{
    public class EventsControllerTests
    {
        [Fact]
        public async Task CreateEvent_AsOrganiser_Returns201()
        {
            // Arrange
            using var context = TestDbContextFactory.Create();
            TestDataSeeder.SeedUsers(context);
            var service = new EventService(context);
            var controller = new EventsController(service);
            SetUser(controller, userId: 1, role: RoleConstants.Organiser);

            var dto = new CreateEventDto
            {
                EventName = "New Event",
                EventDate = DateTime.UtcNow.AddDays(30),
                Location = "Test",
                Distance = "10km",
                EventType = "Run",
                MaxParticipants = 100
            };

            // Act
            var result = await controller.CreateEvent(dto);

            // Assert
            result.Should().BeOfType<CreatedAtActionResult>();
        }

        [Fact]
        public async Task GetEvent_WithValidId_Returns200()
        {
            // Arrange
            using var context = TestDbContextFactory.Create();
            TestDataSeeder.SeedAll(context);
            var service = new EventService(context);
            var controller = new EventsController(service);

            // Act
            var result = await controller.GetEvent(1);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
        }

        [Fact]
        public async Task GetEvent_WithInvalidId_Returns404()
        {
            // Arrange
            using var context = TestDbContextFactory.Create();
            var service = new EventService(context);
            var controller = new EventsController(service);

            // Act
            var result = await controller.GetEvent(999);

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();
        }

        [Fact]
        public async Task GetAllEvents_Returns200WithList()
        {
            // Arrange
            using var context = TestDbContextFactory.Create();
            TestDataSeeder.SeedAll(context);
            var service = new EventService(context);
            var controller = new EventsController(service);

            // Act
            var result = await controller.GetAllEvents(null, null);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
        }

        private static void SetUser(ControllerBase controller, int userId, string role)
        {
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, userId.ToString()),
                new Claim(ClaimTypes.Role, role)
            };
            var identity = new ClaimsIdentity(claims);
            controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext
                {
                    User = new ClaimsPrincipal(identity)
                }
            };
        }
    }
}