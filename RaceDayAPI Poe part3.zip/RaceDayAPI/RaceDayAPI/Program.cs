using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using RaceDayAPI.Data;
using RaceDayAPI.Helpers;
using RaceDayAPI.Services.Implementations;
using RaceDayAPI.Services.Interfaces;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// ============================================
// 1. DATABASE CONFIGURATION
// ============================================
builder.Services.AddDbContext<RaceDayDbContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("DefaultConnection"),
        sqlOptions => sqlOptions.EnableRetryOnFailure()
    )
);

// ============================================
// 2. JWT AUTHENTICATION
// ============================================
var jwtKey = builder.Configuration["Jwt:Key"] ?? "SuperSecretKeyForRaceDaySystem12345678901234567890";
var jwtIssuer = builder.Configuration["Jwt:Issuer"] ?? "RaceDayAPI";
var jwtAudience = builder.Configuration["Jwt:Audience"] ?? "RaceDayClient";

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.RequireHttpsMetadata = false;
    options.SaveToken = true;
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = jwtIssuer,
        ValidAudience = jwtAudience,
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey)),
        ClockSkew = TimeSpan.Zero
    };
});

// ============================================
// 3. AUTHORIZATION POLICIES
// ============================================
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("OrganiserOnly", policy => policy.RequireRole(RoleConstants.Organiser));
    options.AddPolicy("ParticipantOnly", policy => policy.RequireRole(RoleConstants.Participant));
    options.AddPolicy("Authenticated", policy => policy.RequireAuthenticatedUser());
});

// ============================================
// 4. REGISTER SERVICES
// ============================================
builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddScoped<IUserService, UserService>();
builder.Services.AddScoped<IEventService, EventService>();
builder.Services.AddScoped<ICategoryService, CategoryService>();
builder.Services.AddScoped<IEnrolmentService, EnrolmentService>();
builder.Services.AddScoped<IResultService, ResultService>();
builder.Services.AddScoped<IBlobService, BlobService>(); // <-- BLOB SERVICE
builder.Services.AddScoped<JwtHelper>();

// ============================================
// 5. CONTROLLERS & FILE UPLOAD FIX
// ============================================
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNamingPolicy = System.Text.Json.JsonNamingPolicy.CamelCase;
        options.JsonSerializerOptions.DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull;
    });

// FIX: Increase file upload limit to 10MB (for event banners & profile pictures)
builder.Services.Configure<FormOptions>(options =>
{
    options.ValueLengthLimit = int.MaxValue;
    options.MultipartBodyLengthLimit = 10485760; // 10MB
    options.MultipartHeadersLengthLimit = int.MaxValue;
});

// ============================================
// 6. CORS (ALLOW MVC APP TO TALK TO API)
// ============================================
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowMVC", policy =>
    {
        // IMPORTANT: Make sure these ports match your RaceDayMVC launchSettings.json!
        policy.WithOrigins(
                "https://localhost:7100", // Default MVC HTTPS port
                "http://localhost:5100",  // Default MVC HTTP port
                "https://localhost:5001", // In case they run on same port
                "http://localhost:5000"
              )
              .AllowAnyMethod()
              .AllowAnyHeader()
              .AllowCredentials();
    });
});

// ============================================
// 7. SWAGGER CONFIGURATION
// ============================================
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new OpenApiInfo { Title = "RaceDay API", Version = "v1" });
    options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = "Enter JWT token."
    });
    options.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" }
            },
            Array.Empty<string>()
        }
    });
});

var app = builder.Build();

// ============================================
// 8. AUTOMATIC MIGRATION
// ============================================
using (var scope = app.Services.CreateScope())
{
    var dbContext = scope.ServiceProvider.GetRequiredService<RaceDayDbContext>();
    try { dbContext.Database.Migrate(); }
    catch (Exception ex) { /* Log error here */ }
}

// ============================================
// 9. MIDDLEWARE PIPELINE
// ============================================

// Global exception handler
app.UseMiddleware<ExceptionMiddleware>();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

// CORS MUST be before Authentication and Authorization
app.UseCors("AllowMVC");

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();