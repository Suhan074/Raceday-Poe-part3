using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDayAPI.Data;
using RaceDayAPI.DTOs.Events;
using RaceDayAPI.Helpers;
using RaceDayAPI.Services.Interfaces;

namespace RaceDayAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventsController : ControllerBase
    {
        private readonly RaceDayDbContext _context;
        private readonly IBlobService _blobService;

        public EventsController(RaceDayDbContext context, IBlobService blobService)
        {
            _context = context;
            _blobService = blobService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllEvents([FromQuery] string? status, [FromQuery] string? search)
        {
            var query = _context.Events.Include(e => e.Organiser).Include(e => e.Categories).AsQueryable();
            if (!string.IsNullOrEmpty(status)) query = query.Where(e => e.Status == status);
            if (!string.IsNullOrEmpty(search)) query = query.Where(e => e.EventName.Contains(search) || e.Location.Contains(search));

            var events = await query.Select(e => new EventListDto
            {
                EventID = e.EventID,
                EventName = e.EventName,
                Description = e.Description,
                BannerImageUrl = e.BannerImageUrl,
                EventDate = e.EventDate,
                Location = e.Location,
                Distance = e.Distance,
                EventType = e.EventType,
                MaxParticipants = e.MaxParticipants,
                Status = e.Status,
                OrganiserName = e.Organiser.FullName,
                CategoryCount = e.Categories.Count
            }).ToListAsync();

            return Ok(events);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetEvent(int id)
        {
            var ev = await _context.Events.Include(e => e.Organiser).Include(e => e.Categories).FirstOrDefaultAsync(e => e.EventID == id);
            if (ev == null) return NotFound(new { message = "Event not found" });

            return Ok(new EventDetailDto
            {
                EventID = ev.EventID,
                EventName = ev.EventName,
                Description = ev.Description,
                BannerImageUrl = ev.BannerImageUrl,
                EventDate = ev.EventDate,
                Location = ev.Location,
                Distance = ev.Distance,
                EventType = ev.EventType,
                MaxParticipants = ev.MaxParticipants,
                Status = ev.Status,
                OrganiserName = ev.Organiser.FullName,
                Categories = ev.Categories.Select(c => new RaceDayAPI.DTOs.Categories.CategoryListDto
                {
                    CategoryID = c.CategoryID,
                    CategoryName = c.CategoryName,
                    Description = c.Description,
                    MinAge = c.MinAge,
                    MaxAge = c.MaxAge,
                    GenderRestriction = c.GenderRestriction,
                    EventID = c.EventID,
                    EventName = ev.EventName
                }).ToList()
            });
        }

        [HttpPost]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> CreateEvent([FromBody] CreateEventDto dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);
            if (!ValidationHelper.IsValidEventType(dto.EventType)) return BadRequest(new { message = "Invalid event type" });
            if (dto.EventDate <= DateTime.UtcNow) return BadRequest(new { message = "Event date must be in the future" });

            var ev = new RaceDayAPI.Models.Event
            {
                OrganiserID = User.GetUserId(),
                EventName = dto.EventName,
                Description = dto.Description,
                EventDate = dto.EventDate,
                Location = dto.Location,
                Distance = dto.Distance,
                EventType = dto.EventType,
                MaxParticipants = dto.MaxParticipants,
                Status = dto.Status ?? "Upcoming"
            };

            _context.Events.Add(ev);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetEvent), new { id = ev.EventID }, ev);
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> UpdateEvent(int id, [FromBody] CreateEventDto dto)
        {
            var ev = await _context.Events.FindAsync(id);
            if (ev == null) return NotFound(new { message = "Event not found" });
            if (ev.OrganiserID != User.GetUserId()) return StatusCode(403, new { message = "Not your event" });

            ev.EventName = dto.EventName;
            ev.Description = dto.Description;
            ev.EventDate = dto.EventDate;
            ev.Location = dto.Location;
            ev.Distance = dto.Distance;
            ev.EventType = dto.EventType;
            ev.MaxParticipants = dto.MaxParticipants;
            ev.Status = dto.Status ?? ev.Status;
            ev.UpdatedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();
            return Ok(ev);
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> DeleteEvent(int id)
        {
            var ev = await _context.Events.FindAsync(id);
            if (ev == null) return NotFound(new { message = "Event not found" });
            if (ev.OrganiserID != User.GetUserId()) return StatusCode(403, new { message = "Not your event" });

            _context.Events.Remove(ev);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpGet("{id}/categories")]
        public async Task<IActionResult> GetEventCategories(int id)
        {
            var categories = await _context.Categories.Where(c => c.EventID == id).Select(c => new
            {
                c.CategoryID, c.CategoryName, c.Description, c.MinAge, c.MaxAge, c.GenderRestriction, c.EventID, EnrolmentCount = c.Enrolments.Count
            }).ToListAsync();
            return Ok(categories);
        }

        [HttpGet("{id}/enrolments")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> GetEventEnrolments(int id)
        {
            var ev = await _context.Events.FindAsync(id);
            if (ev == null) return NotFound(new { message = "Event not found" });
            if (ev.OrganiserID != User.GetUserId()) return StatusCode(403, new { message = "Not your event" });

            var enrolments = await _context.Enrolments.Include(e => e.Participant).Include(e => e.Category).Where(e => e.Category.EventID == id)
                .Select(e => new { e.EnrolmentID, ParticipantName = e.Participant.FullName, ParticipantEmail = e.Participant.Email, CategoryName = e.Category.CategoryName, e.EnrolmentDate, e.Status, e.PaymentStatus }).ToListAsync();
            return Ok(enrolments);
        }

        // NEW ENDPOINT: Upload Event Banner
        [HttpPost("{id}/upload-banner")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> UploadBanner(int id, IFormFile file)
        {
            if (file == null || file.Length == 0) return BadRequest(new { message = "No file provided" });

            var ev = await _context.Events.FindAsync(id);
            if (ev == null) return NotFound(new { message = "Event not found" });
            if (ev.OrganiserID != User.GetUserId()) return StatusCode(403, new { message = "Not your event" });

            var imageUrl = await _blobService.UploadFileAsync(file);
            ev.BannerImageUrl = imageUrl;
            ev.UpdatedAt = DateTime.UtcNow;
            
            await _context.SaveChangesAsync();
            return Ok(new { imageUrl });
        }
    }
}