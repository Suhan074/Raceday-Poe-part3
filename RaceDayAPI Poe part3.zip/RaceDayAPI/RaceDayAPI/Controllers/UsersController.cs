using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDayAPI.Data;
using RaceDayAPI.DTOs.Users;
using RaceDayAPI.Helpers;
using RaceDayAPI.Services.Interfaces;

namespace RaceDayAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class UsersController : ControllerBase
    {
        private readonly RaceDayDbContext _context;
        private readonly IBlobService _blobService;

        public UsersController(RaceDayDbContext context, IBlobService blobService)
        {
            _context = context;
            _blobService = blobService;
        }

        [HttpGet("profile")]
        public async Task<IActionResult> GetProfile()
        {
            var user = await _context.Users.FindAsync(User.GetUserId());
            if (user == null) return NotFound(new { message = "User not found" });

            return Ok(new UserProfileDto
            {
                UserID = user.UserID,
                Email = user.Email,
                FullName = user.FullName,
                ProfileImageUrl = user.ProfileImageUrl,
                Role = user.Role,
                CreatedAt = user.CreatedAt
            });
        }

        [HttpPut("profile")]
        public async Task<IActionResult> UpdateProfile([FromBody] UpdateProfileDto dto)
        {
            var user = await _context.Users.FindAsync(User.GetUserId());
            if (user == null) return NotFound(new { message = "User not found" });

            if (dto.Email != user.Email && _context.Users.Any(u => u.Email == dto.Email))
                return Conflict(new { message = "Email already in use" });

            user.FullName = dto.FullName ?? user.FullName;
            user.Email = dto.Email ?? user.Email;
            user.UpdatedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();
            return Ok(new { message = "Profile updated successfully" });
        }

        // NEW ENDPOINT: Upload Profile Picture
        [HttpPost("upload-profile-picture")]
        public async Task<IActionResult> UploadProfilePicture(IFormFile file)
        {
            if (file == null || file.Length == 0) return BadRequest(new { message = "No file provided" });

            var user = await _context.Users.FindAsync(User.GetUserId());
            if (user == null) return NotFound(new { message = "User not found" });

            var imageUrl = await _blobService.UploadFileAsync(file);
            user.ProfileImageUrl = imageUrl;
            user.UpdatedAt = DateTime.UtcNow;
            
            await _context.SaveChangesAsync();
            return Ok(new { imageUrl });
        }

        [HttpGet("participants")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> GetAllParticipants()
        {
            var participants = await _context.Users
                .Where(u => u.Role == RoleConstants.Participant)
                .Select(u => new ParticipantDto
                {
                    UserID = u.UserID,
                    Email = u.Email,
                    FullName = u.FullName,
                    EnrolmentCount = u.Enrolments.Count
                })
                .ToListAsync();
            return Ok(participants);
        }
    }
}