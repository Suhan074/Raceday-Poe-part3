using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using RaceDayAPI.Data;
using RaceDayAPI.Models;

namespace RaceDayAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class ResultsController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public ResultsController(RaceDayDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Add a result for an enrolment (Organiser only)
        /// </summary>
        [HttpPost]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> AddResult([FromBody] CreateResultDto dto)
        {
            var enrolment = await _context.Enrolments
                .Include(e => e.Category)
                    .ThenInclude(c => c.Event)
                .FirstOrDefaultAsync(e => e.EnrolmentID == dto.EnrolmentId);

            if (enrolment == null)
                return NotFound(new { message = "Enrolment not found" });

            var organiserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            if (enrolment.Category.Event.OrganiserID != organiserId)
                return StatusCode(403, new { message = "Not your event" });

            if (_context.Results.Any(r => r.EnrolmentID == dto.EnrolmentId))
                return Conflict(new { message = "Result already exists for this enrolment" });

            var result = new Result
            {
                EnrolmentID = dto.EnrolmentId,
                FinishTime = dto.FinishTime,
                Position = dto.Position,
                Status = dto.Status ?? "Finished",
                Notes = dto.Notes,
                UpdatedAt = DateTime.UtcNow
            };

            _context.Results.Add(result);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetResult), new { id = result.ResultID }, result);
        }

        /// <summary>
        /// Get current user's results (Participant only)
        /// </summary>
        [HttpGet("participant")]
        [Authorize(Roles = "Participant")]
        public async Task<IActionResult> GetMyResults()
        {
            var participantId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");

            var results = await _context.Results
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e.Category)
                        .ThenInclude(c => c.Event)
                .Where(r => r.Enrolment.ParticipantID == participantId)
                .Select(r => new
                {
                    r.ResultID,
                    EventName = r.Enrolment.Category.Event.EventName,
                    CategoryName = r.Enrolment.Category.CategoryName,
                    r.FinishTime,
                    r.Position,
                    r.Status,
                    r.Notes
                })
                .ToListAsync();

            return Ok(results);
        }

        /// <summary>
        /// Get result by ID
        /// </summary>
        [HttpGet("{id}")]
        public async Task<IActionResult> GetResult(int id)
        {
            var result = await _context.Results
                .Include(r => r.Enrolment)
                .FirstOrDefaultAsync(r => r.ResultID == id);

            if (result == null)
                return NotFound(new { message = "Result not found" });

            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var userRole = User.FindFirst(ClaimTypes.Role)?.Value ?? "";

            if (userRole != "Organiser" && result.Enrolment.ParticipantID != userId)
                return StatusCode(403, new { message = "Access denied" });

            return Ok(result);
        }

        /// <summary>
        /// Get result for an enrolment
        /// </summary>
        [HttpGet("enrolment/{enrolmentId}")]
        public async Task<IActionResult> GetResultByEnrolment(int enrolmentId)
        {
            var result = await _context.Results
                .Include(r => r.Enrolment)
                .FirstOrDefaultAsync(r => r.EnrolmentID == enrolmentId);

            if (result == null)
                return NotFound(new { message = "Result not found" });

            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var userRole = User.FindFirst(ClaimTypes.Role)?.Value ?? "";

            if (userRole != "Organiser" && result.Enrolment.ParticipantID != userId)
                return StatusCode(403, new { message = "Access denied" });

            return Ok(result);
        }

        /// <summary>
        /// Update result (Organiser only)
        /// </summary>
        [HttpPut("{id}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> UpdateResult(int id, [FromBody] CreateResultDto dto)
        {
            var result = await _context.Results
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e.Category)
                        .ThenInclude(c => c.Event)
                .FirstOrDefaultAsync(r => r.ResultID == id);

            if (result == null)
                return NotFound(new { message = "Result not found" });

            var organiserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            if (result.Enrolment.Category.Event.OrganiserID != organiserId)
                return StatusCode(403, new { message = "Not your event" });

            result.FinishTime = dto.FinishTime;
            result.Position = dto.Position;
            result.Status = dto.Status ?? result.Status;
            result.Notes = dto.Notes;
            result.UpdatedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();
            return Ok(result);
        }

        /// <summary>
        /// Delete result (Organiser only)
        /// </summary>
        [HttpDelete("{id}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> DeleteResult(int id)
        {
            var result = await _context.Results
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e.Category)
                        .ThenInclude(c => c.Event)
                .FirstOrDefaultAsync(r => r.ResultID == id);

            if (result == null)
                return NotFound(new { message = "Result not found" });

            var organiserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            if (result.Enrolment.Category.Event.OrganiserID != organiserId)
                return StatusCode(403, new { message = "Not your event" });

            _context.Results.Remove(result);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        /// <summary>
        /// Get all results for an event (Organiser only)
        /// </summary>
        [HttpGet("event/{eventId}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> GetEventResults(int eventId)
        {
            var ev = await _context.Events.FindAsync(eventId);
            if (ev == null)
                return NotFound(new { message = "Event not found" });

            var organiserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            if (ev.OrganiserID != organiserId)
                return StatusCode(403, new { message = "Not your event" });

            var results = await _context.Results
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e.Participant)
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e.Category)
                .Where(r => r.Enrolment.Category.EventID == eventId)
                .Select(r => new
                {
                    r.ResultID,
                    ParticipantName = r.Enrolment.Participant.FullName,
                    CategoryName = r.Enrolment.Category.CategoryName,
                    r.FinishTime,
                    r.Position,
                    r.Status,
                    r.Notes
                })
                .ToListAsync();

            return Ok(results);
        }

        /// <summary>
        /// Get public leaderboard for an event (Public)
        /// </summary>
        [HttpGet("leaderboard/{eventId}")]
        [AllowAnonymous]
        public async Task<IActionResult> GetLeaderboard(int eventId)
        {
            var leaderboard = await _context.Results
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e.Category)
                .Where(r => r.Enrolment.Category.EventID == eventId
                         && r.Status == "Finished"
                         && r.Position != null)
                .OrderBy(r => r.Position)
                .Select(r => new
                {
                    Position = r.Position,
                    ParticipantName = r.Enrolment.Participant.FullName,
                    CategoryName = r.Enrolment.Category.CategoryName,
                    r.FinishTime
                })
                .ToListAsync();

            return Ok(leaderboard);
        }
    }

    public class CreateResultDto
    {
        public int EnrolmentId { get; set; }
        public TimeSpan? FinishTime { get; set; }
        public int? Position { get; set; }
        public string? Status { get; set; }
        public string? Notes { get; set; }
    }
}