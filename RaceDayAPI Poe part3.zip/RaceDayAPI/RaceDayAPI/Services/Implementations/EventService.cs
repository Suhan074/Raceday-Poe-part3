using Microsoft.EntityFrameworkCore;
using RaceDayAPI.Data;
using RaceDayAPI.DTOs.Categories;
using RaceDayAPI.DTOs.Events;
using RaceDayAPI.Helpers;
using RaceDayAPI.Models;
using RaceDayAPI.Services.Interfaces;

namespace RaceDayAPI.Services.Implementations
{
    public class EventService : IEventService
    {
        private readonly RaceDayDbContext _context;

        public EventService(RaceDayDbContext context)
        {
            _context = context;
        }

        public async Task<List<EventListDto>> GetAllEventsAsync(string? status, string? search)
        {
            var query = _context.Events
                .Include(e => e.Organiser)
                .Include(e => e.Categories)
                .AsQueryable();

            if (!string.IsNullOrEmpty(status))
                query = query.Where(e => e.Status == status);

            if (!string.IsNullOrEmpty(search))
                query = query.Where(e =>
                    e.EventName.Contains(search) || e.Location.Contains(search));

            return await query
                .OrderBy(e => e.EventDate)
                .Select(e => new EventListDto
                {
                    EventID = e.EventID,
                    EventName = e.EventName,
                    Description = e.Description,
                    EventDate = e.EventDate,
                    Location = e.Location,
                    Distance = e.Distance,
                    EventType = e.EventType,
                    MaxParticipants = e.MaxParticipants,
                    Status = e.Status,
                    OrganiserName = e.Organiser.FullName,
                    CategoryCount = e.Categories.Count
                })
                .ToListAsync();
        }

        public async Task<EventDetailDto?> GetEventByIdAsync(int id)
        {
            var ev = await _context.Events
                .Include(e => e.Organiser)
                .Include(e => e.Categories)
                .FirstOrDefaultAsync(e => e.EventID == id);

            if (ev == null) return null;

            return new EventDetailDto
            {
                EventID = ev.EventID,
                EventName = ev.EventName,
                Description = ev.Description,
                EventDate = ev.EventDate,
                Location = ev.Location,
                Distance = ev.Distance,
                EventType = ev.EventType,
                MaxParticipants = ev.MaxParticipants,
                Status = ev.Status,
                OrganiserName = ev.Organiser.FullName,
                Categories = ev.Categories.Select(c => new CategoryListDto
                {
                    CategoryID = c.CategoryID,
                    CategoryName = c.CategoryName,
                    Description = c.Description,
                    MinAge = c.MinAge,
                    MaxAge = c.MaxAge,
                    GenderRestriction = c.GenderRestriction,
                    EventID = c.EventID,
                    EventName = ev.EventName
                }).ToList()
            };
        }

        public async Task<EventDetailDto> CreateEventAsync(int organiserId, CreateEventDto dto)
        {
            // Validation
            if (!ValidationHelper.IsValidEventType(dto.EventType))
                throw new InvalidOperationException("Event type must be Run, Walk, or Cycle");

            if (dto.EventDate <= DateTime.UtcNow)
                throw new InvalidOperationException("Event date must be in the future");

            if (dto.MaxParticipants <= 0)
                throw new InvalidOperationException("Max participants must be greater than 0");

            if (!string.IsNullOrEmpty(dto.Status) && !ValidationHelper.IsValidEventStatus(dto.Status))
                throw new InvalidOperationException("Invalid event status");

            var ev = new Event
            {
                OrganiserID = organiserId,
                EventName = dto.EventName,
                Description = dto.Description,
                EventDate = dto.EventDate,
                Location = dto.Location,
                Distance = dto.Distance,
                EventType = dto.EventType,
                MaxParticipants = dto.MaxParticipants,
                Status = dto.Status ?? StatusConstants.EventStatus.Upcoming,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            _context.Events.Add(ev);
            await _context.SaveChangesAsync();

            return (await GetEventByIdAsync(ev.EventID))!;
        }

        public async Task<bool> UpdateEventAsync(int id, int organiserId, CreateEventDto dto)
        {
            var ev = await _context.Events.FindAsync(id);
            if (ev == null) return false;

            if (ev.OrganiserID != organiserId)
                throw new UnauthorizedAccessException("Not your event");

            if (!ValidationHelper.IsValidEventType(dto.EventType))
                throw new InvalidOperationException("Event type must be Run, Walk, or Cycle");

            if (!string.IsNullOrEmpty(dto.Status) && !ValidationHelper.IsValidEventStatus(dto.Status))
                throw new InvalidOperationException("Invalid event status");

            ev.EventName = dto.EventName;
            ev.Description = dto.Description;
            ev.EventDate = dto.EventDate;
            ev.Location = dto.Location;
            ev.Distance = dto.Distance;
            ev.EventType = dto.EventType;
            ev.MaxParticipants = dto.MaxParticipants;
            ev.Status = dto.Status ?? ev.Status;
            ev.UpdatedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteEventAsync(int id, int organiserId)
        {
            var ev = await _context.Events.FindAsync(id);
            if (ev == null) return false;

            if (ev.OrganiserID != organiserId)
                throw new UnauthorizedAccessException("Not your event");

            _context.Events.Remove(ev);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<List<CategoryListDto>> GetEventCategoriesAsync(int eventId)
        {
            return await _context.Categories
                .Where(c => c.EventID == eventId)
                .Select(c => new CategoryListDto
                {
                    CategoryID = c.CategoryID,
                    CategoryName = c.CategoryName,
                    Description = c.Description,
                    MinAge = c.MinAge,
                    MaxAge = c.MaxAge,
                    GenderRestriction = c.GenderRestriction,
                    EventID = c.EventID,
                    EventName = c.Event.EventName,
                    EnrolmentCount = c.Enrolments.Count
                })
                .ToListAsync();
        }

        public async Task<List<EventEnrolmentDto>> GetEventEnrolmentsAsync(int eventId, int organiserId)
        {
            var ev = await _context.Events.FindAsync(eventId);
            if (ev == null)
                throw new KeyNotFoundException("Event not found");

            if (ev.OrganiserID != organiserId)
                throw new UnauthorizedAccessException("Not your event");

            return await _context.Enrolments
                .Include(e => e.Participant)
                .Include(e => e.Category)
                .Where(e => e.Category.EventID == eventId)
                .Select(e => new EventEnrolmentDto
                {
                    EnrolmentID = e.EnrolmentID,
                    ParticipantName = e.Participant.FullName,
                    ParticipantEmail = e.Participant.Email,
                    CategoryName = e.Category.CategoryName,
                    EnrolmentDate = e.EnrolmentDate,
                    Status = e.Status,
                    PaymentStatus = e.PaymentStatus
                })
                .ToListAsync();
        }

        public async Task<bool> IsEventOwnerAsync(int eventId, int organiserId)
        {
            return await _context.Events
                .AnyAsync(e => e.EventID == eventId && e.OrganiserID == organiserId);
        }
    }
}