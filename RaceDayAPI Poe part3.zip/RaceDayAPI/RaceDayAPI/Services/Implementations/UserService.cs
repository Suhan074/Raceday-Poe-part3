using Microsoft.EntityFrameworkCore;
using RaceDayAPI.Data;
using RaceDayAPI.DTOs.Users;
using RaceDayAPI.Helpers;
using RaceDayAPI.Services.Interfaces;

namespace RaceDayAPI.Services.Implementations
{
    public class UserService : IUserService
    {
        private readonly RaceDayDbContext _context;

        public UserService(RaceDayDbContext context)
        {
            _context = context;
        }

        public async Task<UserProfileDto?> GetProfileAsync(int userId)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null) return null;

            return new UserProfileDto
            {
                UserID = user.UserID,
                Email = user.Email,
                FullName = user.FullName,
                Role = user.Role,
                CreatedAt = user.CreatedAt
            };
        }

        public async Task<bool> UpdateProfileAsync(int userId, UpdateProfileDto dto)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null) return false;

            // Check email uniqueness
            if (!string.IsNullOrEmpty(dto.Email) && dto.Email != user.Email)
            {
                if (!ValidationHelper.IsValidEmail(dto.Email))
                    throw new InvalidOperationException("Invalid email format");

                if (await _context.Users.AnyAsync(u => u.Email == dto.Email))
                    throw new InvalidOperationException("Email already in use");

                user.Email = dto.Email;
            }

            if (!string.IsNullOrEmpty(dto.FullName))
                user.FullName = dto.FullName;

            user.UpdatedAt = DateTime.UtcNow;
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<List<ParticipantDto>> GetAllParticipantsAsync()
        {
            return await _context.Users
                .Where(u => u.Role == RoleConstants.Participant)
                .Select(u => new ParticipantDto
                {
                    UserID = u.UserID,
                    Email = u.Email,
                    FullName = u.FullName,
                    EnrolmentCount = u.Enrolments.Count
                })
                .ToListAsync();
        }

        public async Task<List<UserEnrolmentDto>> GetUserEnrolmentsAsync(int userId)
        {
            return await _context.Enrolments
                .Include(e => e.Category)
                    .ThenInclude(c => c.Event)
                .Include(e => e.Result)
                .Where(e => e.ParticipantID == userId)
                .Select(e => new UserEnrolmentDto
                {
                    EnrolmentID = e.EnrolmentID,
                    EventName = e.Category.Event.EventName,
                    CategoryName = e.Category.CategoryName,
                    EnrolmentDate = e.EnrolmentDate,
                    Status = e.Status,
                    PaymentStatus = e.PaymentStatus,
                    HasResult = e.Result != null
                })
                .ToListAsync();
        }
    }
}