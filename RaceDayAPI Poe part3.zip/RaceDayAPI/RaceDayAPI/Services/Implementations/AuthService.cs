using Microsoft.EntityFrameworkCore;
using RaceDayAPI.Data;
using RaceDayAPI.DTOs.Auth;
using RaceDayAPI.Helpers;
using RaceDayAPI.Models;
using RaceDayAPI.Services.Interfaces;

namespace RaceDayAPI.Services.Implementations
{
    public class AuthService : IAuthService
    {
        private readonly RaceDayDbContext _context;
        private readonly JwtHelper _jwtHelper;

        public AuthService(RaceDayDbContext context, JwtHelper jwtHelper)
        {
            _context = context;
            _jwtHelper = jwtHelper;
        }

        public async Task<AuthResponseDto> RegisterAsync(RegisterDto dto)
        {
            // Check email
            if (await EmailExistsAsync(dto.Email))
                throw new InvalidOperationException("Email already registered");

            // Validate role
            if (!ValidationHelper.IsValidRole(dto.Role))
                throw new InvalidOperationException("Role must be 'Organiser' or 'Participant'");

            // Validate password strength
            if (!PasswordHelper.IsStrongPassword(dto.Password))
                throw new InvalidOperationException(PasswordHelper.GetPasswordRequirements());

            // Create user
            var user = new User
            {
                Email = dto.Email,
                PasswordHash = PasswordHelper.HashPassword(dto.Password),
                FullName = dto.FullName,
                Role = dto.Role,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            // Generate token
            var token = _jwtHelper.GenerateToken(user);

            return new AuthResponseDto
            {
                Token = token,
                User = new UserInfoDto
                {
                    UserID = user.UserID,
                    Email = user.Email,
                    FullName = user.FullName,
                    Role = user.Role
                }
            };
        }

        public async Task<AuthResponseDto> LoginAsync(LoginDto dto)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == dto.Email);

            if (user == null)
                throw new UnauthorizedAccessException("Invalid email or password");

            if (!PasswordHelper.VerifyPassword(dto.Password, user.PasswordHash))
                throw new UnauthorizedAccessException("Invalid email or password");

            var token = _jwtHelper.GenerateToken(user);

            return new AuthResponseDto
            {
                Token = token,
                User = new UserInfoDto
                {
                    UserID = user.UserID,
                    Email = user.Email,
                    FullName = user.FullName,
                    Role = user.Role
                }
            };
        }

        public async Task<bool> EmailExistsAsync(string email)
        {
            return await _context.Users.AnyAsync(u => u.Email == email);
        }
    }
}