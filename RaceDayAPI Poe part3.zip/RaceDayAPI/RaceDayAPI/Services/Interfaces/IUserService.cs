using RaceDayAPI.DTOs.Users;

namespace RaceDayAPI.Services.Interfaces
{
    public interface IUserService
    {
        Task<UserProfileDto?> GetProfileAsync(int userId);
        Task<bool> UpdateProfileAsync(int userId, UpdateProfileDto dto);
        Task<List<ParticipantDto>> GetAllParticipantsAsync();
        Task<List<UserEnrolmentDto>> GetUserEnrolmentsAsync(int userId);
    }
}