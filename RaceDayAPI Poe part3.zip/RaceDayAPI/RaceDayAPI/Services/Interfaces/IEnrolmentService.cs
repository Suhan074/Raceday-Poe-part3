using RaceDayAPI.DTOs.Enrolments;

namespace RaceDayAPI.Services.Interfaces
{
    public interface IEnrolmentService
    {
        Task<EnrolmentDto> CreateEnrolmentAsync(int participantId, CreateEnrolmentDto dto);
        Task<List<MyEnrolmentDto>> GetMyEnrolmentsAsync(int participantId);
        Task<EnrolmentDetailDto?> GetEnrolmentByIdAsync(int id, int userId, string role);
        Task<bool> UpdateEnrolmentStatusAsync(int id, int organiserId, string status);
        Task<bool> CancelEnrolmentAsync(int id, int participantId);
        Task<List<EventEnrolmentDto>> GetEventEnrolmentsAsync(int eventId, int organiserId);
    }
}