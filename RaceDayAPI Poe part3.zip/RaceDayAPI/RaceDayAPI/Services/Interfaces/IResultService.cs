using RaceDayAPI.DTOs.Results;

namespace RaceDayAPI.Services.Interfaces
{
    public interface IResultService
    {
        Task<ResultDto> AddResultAsync(int organiserId, CreateResultDto dto);
        Task<List<MyResultDto>> GetMyResultsAsync(int participantId);
        Task<ResultDetailDto?> GetResultByIdAsync(int id, int userId, string role);
        Task<ResultDetailDto?> GetResultByEnrolmentAsync(int enrolmentId, int userId, string role);
        Task<bool> UpdateResultAsync(int id, int organiserId, UpdateResultDto dto);
        Task<bool> DeleteResultAsync(int id, int organiserId);
        Task<List<EventResultDto>> GetEventResultsAsync(int eventId, int organiserId);
        Task<List<LeaderboardDto>> GetLeaderboardAsync(int eventId);
    }
}