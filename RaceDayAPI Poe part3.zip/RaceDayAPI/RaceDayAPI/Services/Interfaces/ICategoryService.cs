using RaceDayAPI.DTOs.Categories;

namespace RaceDayAPI.Services.Interfaces
{
    public interface ICategoryService
    {
        Task<List<CategoryListDto>> GetAllCategoriesAsync(int? eventId);
        Task<CategoryDetailDto?> GetCategoryByIdAsync(int id);
        Task<CategoryDetailDto> CreateCategoryAsync(int eventId, int organiserId, CreateCategoryDto dto);
        Task<bool> UpdateCategoryAsync(int id, int organiserId, CreateCategoryDto dto);
        Task<bool> DeleteCategoryAsync(int id, int organiserId);
        Task<List<CategoryEnrolmentDto>> GetCategoryEnrolmentsAsync(int id, int organiserId);
    }
}