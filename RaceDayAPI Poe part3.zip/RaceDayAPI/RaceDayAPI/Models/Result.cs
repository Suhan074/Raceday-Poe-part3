using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RaceDayAPI.Models
{
    /// <summary>
    /// Represents a race result for an enrolment
    /// </summary>
    public class Result
    {
        [Key]
        public int ResultID { get; set; }

        [Required]
        public int EnrolmentID { get; set; }

        public TimeSpan? FinishTime { get; set; }

        public int? Position { get; set; }

        [Required]
        [MaxLength(50)]
        public string Status { get; set; } = "DNS"; // "DNS", "DNF", "Finished", "Disqualified"

        public string? Notes { get; set; }

        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

        // Navigation Properties
        [ForeignKey(nameof(EnrolmentID))]
        public Enrolment Enrolment { get; set; } = null!;
    }
}