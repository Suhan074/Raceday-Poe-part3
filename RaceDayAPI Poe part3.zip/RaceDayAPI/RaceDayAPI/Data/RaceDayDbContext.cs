using Microsoft.EntityFrameworkCore;
using RaceDayAPI.Models;

namespace RaceDayAPI.Data
{
    public class RaceDayDbContext : DbContext
    {
        public RaceDayDbContext(DbContextOptions<RaceDayDbContext> options)
            : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<Event> Events { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Enrolment> Enrolments { get; set; }
        public DbSet<Result> Results { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // -------------------------
            // USER CONFIGURATION
            // -------------------------
            modelBuilder.Entity<User>(entity =>
            {
                entity.HasIndex(u => u.Email).IsUnique();

                entity.Property(u => u.Role)
                      .HasDefaultValue("Participant");

                // One Organiser has many Events
                entity.HasMany(u => u.Events)
                      .WithOne(e => e.Organiser)
                      .HasForeignKey(e => e.OrganiserID)
                      .OnDelete(DeleteBehavior.Cascade);

                // One Participant has many Enrolments
                entity.HasMany(u => u.Enrolments)
                      .WithOne(e => e.Participant)
                      .HasForeignKey(e => e.ParticipantID)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            // -------------------------
            // EVENT CONFIGURATION
            // -------------------------
            modelBuilder.Entity<Event>(entity =>
            {
                entity.Property(e => e.Status)
                      .HasDefaultValue("Upcoming");

                entity.Property(e => e.EventType)
                      .HasDefaultValue("Run");

                // One Event has many Categories
                entity.HasMany(e => e.Categories)
                      .WithOne(c => c.Event)
                      .HasForeignKey(c => c.EventID)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            // -------------------------
            // CATEGORY CONFIGURATION
            // -------------------------
            modelBuilder.Entity<Category>(entity =>
            {
                entity.Property(c => c.GenderRestriction)
                      .HasDefaultValue("None");

                // One Category has many Enrolments
                entity.HasMany(c => c.Enrolments)
                      .WithOne(e => e.Category)
                      .HasForeignKey(e => e.CategoryID)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            // -------------------------
            // ENROLMENT CONFIGURATION
            // -------------------------
            modelBuilder.Entity<Enrolment>(entity =>
            {
                entity.Property(e => e.Status)
                      .HasDefaultValue("Pending");

                entity.Property(e => e.PaymentStatus)
                      .HasDefaultValue("Pending");

                // A participant cannot enrol twice in the same category
                entity.HasIndex(e => new { e.ParticipantID, e.CategoryID })
                      .IsUnique();

                // One Enrolment has one Result
                entity.HasOne(e => e.Result)
                      .WithOne(r => r.Enrolment)
                      .HasForeignKey<Result>(r => r.EnrolmentID)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            // -------------------------
            // RESULT CONFIGURATION
            // -------------------------
            modelBuilder.Entity<Result>(entity =>
            {
                entity.Property(r => r.Status)
                      .HasDefaultValue("DNS");

                // One Result belongs to one Enrolment
                entity.HasIndex(r => r.EnrolmentID).IsUnique();
            });

            // -------------------------
            // SEED DATA (Optional)
            // -------------------------
            SeedData(modelBuilder);
        }

        /// <summary>
        /// Optional: Seed the database with sample data
        /// </summary>
        private void SeedData(ModelBuilder modelBuilder)
        {
            // You can uncomment this if you want seed data via migrations

            /*
            modelBuilder.Entity<User>().HasData(
                new User { UserID = 1, Email = "john@raceday.com", PasswordHash = "hashed1", FullName = "John Organiser", Role = "Organiser" },
                new User { UserID = 2, Email = "sarah@raceday.com", PasswordHash = "hashed2", FullName = "Sarah Organiser", Role = "Organiser" },
                new User { UserID = 3, Email = "mike@email.com", PasswordHash = "hashed3", FullName = "Mike Runner", Role = "Participant" },
                new User { UserID = 4, Email = "emma@email.com", PasswordHash = "hashed4", FullName = "Emma Sprinter", Role = "Participant" }
            );
            */
        }
    }
}