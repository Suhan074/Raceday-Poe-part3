using System.Security.Claims;

namespace RaceDayAPI.Helpers
{
    /// <summary>
    /// Extension methods for reading user info from JWT claims
    /// </summary>
    public static class ClaimsHelper
    {
        /// <summary>
        /// Get the current user's ID
        /// </summary>
        public static int GetUserId(this ClaimsPrincipal user)
        {
            var claim = user.FindFirst(ClaimTypes.NameIdentifier);
            return claim != null && int.TryParse(claim.Value, out var id) ? id : 0;
        }

        /// <summary>
        /// Get the current user's email
        /// </summary>
        public static string GetEmail(this ClaimsPrincipal user)
        {
            return user.FindFirst(ClaimTypes.Email)?.Value ?? string.Empty;
        }

        /// <summary>
        /// Get the current user's full name
        /// </summary>
        public static string GetFullName(this ClaimsPrincipal user)
        {
            return user.FindFirst(ClaimTypes.Name)?.Value ?? string.Empty;
        }

        /// <summary>
        /// Get the current user's role
        /// </summary>
        public static string GetRole(this ClaimsPrincipal user)
        {
            return user.FindFirst(ClaimTypes.Role)?.Value ?? string.Empty;
        }

        /// <summary>
        /// Check if the current user is an Organiser
        /// </summary>
        public static bool IsOrganiser(this ClaimsPrincipal user)
        {
            return user.GetRole() == RoleConstants.Organiser;
        }

        /// <summary>
        /// Check if the current user is a Participant
        /// </summary>
        public static bool IsParticipant(this ClaimsPrincipal user)
        {
            return user.GetRole() == RoleConstants.Participant;
        }
    }
}