namespace RaceDayAPI.Helpers
{
    /// <summary>
    /// Common validation methods used across the API
    /// </summary>
    public static class ValidationHelper
    {
        /// <summary>
        /// Validate if a string is a valid email format
        /// </summary>
        public static bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;

            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Check if an event type is valid (Run, Walk, Cycle)
        /// </summary>
        public static bool IsValidEventType(string eventType)
        {
            if (string.IsNullOrWhiteSpace(eventType))
                return false;

            var validTypes = new[] { "Run", "Walk", "Cycle" };
            return validTypes.Contains(eventType, StringComparer.OrdinalIgnoreCase);
        }

        /// <summary>
        /// Check if an event status is valid
        /// </summary>
        public static bool IsValidEventStatus(string status)
        {
            if (string.IsNullOrWhiteSpace(status))
                return false;

            var validStatuses = new[] { "Upcoming", "Ongoing", "Completed", "Cancelled" };
            return validStatuses.Contains(status, StringComparer.OrdinalIgnoreCase);
        }

        /// <summary>
        /// Check if an enrolment status is valid
        /// </summary>
        public static bool IsValidEnrolmentStatus(string status)
        {
            if (string.IsNullOrWhiteSpace(status))
                return false;

            var validStatuses = new[] { "Pending", "Confirmed", "Cancelled" };
            return validStatuses.Contains(status, StringComparer.OrdinalIgnoreCase);
        }

        /// <summary>
        /// Check if a payment status is valid
        /// </summary>
        public static bool IsValidPaymentStatus(string status)
        {
            if (string.IsNullOrWhiteSpace(status))
                return false;

            var validStatuses = new[] { "Pending", "Paid", "Refunded" };
            return validStatuses.Contains(status, StringComparer.OrdinalIgnoreCase);
        }

        /// <summary>
        /// Check if a result status is valid
        /// </summary>
        public static bool IsValidResultStatus(string status)
        {
            if (string.IsNullOrWhiteSpace(status))
                return false;

            var validStatuses = new[] { "DNS", "DNF", "Finished", "Disqualified" };
            return validStatuses.Contains(status, StringComparer.OrdinalIgnoreCase);
        }

        /// <summary>
        /// Check if a gender restriction is valid
        /// </summary>
        public static bool IsValidGenderRestriction(string restriction)
        {
            if (string.IsNullOrWhiteSpace(restriction))
                return false;

            var validRestrictions = new[] { "None", "Male", "Female" };
            return validRestrictions.Contains(restriction, StringComparer.OrdinalIgnoreCase);
        }

        /// <summary>
        /// Check if a role is valid (Organiser or Participant)
        /// </summary>
        public static bool IsValidRole(string role)
        {
            return role == RoleConstants.Organiser || role == RoleConstants.Participant;
        }

        /// <summary>
        /// Check if an age range is valid
        /// </summary>
        public static bool IsValidAgeRange(int? minAge, int? maxAge)
        {
            if (minAge.HasValue && minAge.Value < 0)
                return false;

            if (maxAge.HasValue && maxAge.Value < 0)
                return false;

            if (minAge.HasValue && maxAge.HasValue && minAge.Value > maxAge.Value)
                return false;

            return true;
        }

        /// <summary>
        /// Check if a date is in the future
        /// </summary>
        public static bool IsFutureDate(DateTime date)
        {
            return date > DateTime.UtcNow;
        }

        /// <summary>
        /// Check if a distance string is valid
        /// </summary>
        public static bool IsValidDistance(string distance)
        {
            if (string.IsNullOrWhiteSpace(distance))
                return false;

            return distance.Length <= 50;
        }
    }
}