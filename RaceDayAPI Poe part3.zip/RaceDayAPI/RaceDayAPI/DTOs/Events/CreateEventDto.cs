using System.ComponentModel.DataAnnotations;

namespace RaceDayAPI.DTOs.Events
{
    /// <summary>
    /// Data sent by an Organiser to create or update an event
    /// </summary>
    public class CreateEventDto
    {
        /// <summary>
        /// Name of the event
        /// </summary>
        [Required(ErrorMessage = "Event name is required")]
        [MaxLength(255, ErrorMessage = "Event name cannot exceed 255 characters")]
        [MinLength(3, ErrorMessage = "Event name must be at least 3 characters")]
        public string EventName { get; set; } = string.Empty;

        /// <summary>
        /// Description of the event (optional)
        /// </summary>
        [MaxLength(2000, ErrorMessage = "Description cannot exceed 2000 characters")]
        public string? Description { get; set; }

        /// <summary>
        /// When the event will take place
        /// </summary>
        [Required(ErrorMessage = "Event date is required")]
        public DateTime EventDate { get; set; }

        /// <summary>
        /// Where the event will take place
        /// </summary>
        [Required(ErrorMessage = "Location is required")]
        [MaxLength(255, ErrorMessage = "Location cannot exceed 255 characters")]
        public string Location { get; set; } = string.Empty;

        /// <summary>
        /// Distance of the event (e.g., "5km", "10km", "42.2km")
        /// </summary>
        [Required(ErrorMessage = "Distance is required")]
        [MaxLength(50, ErrorMessage = "Distance cannot exceed 50 characters")]
        public string Distance { get; set; } = string.Empty;

        /// <summary>
        /// Type of event: "Run", "Walk", or "Cycle"
        /// </summary>
        [Required(ErrorMessage = "Event type is required")]
        [RegularExpression("^(Run|Walk|Cycle)$",
            ErrorMessage = "Event type must be 'Run', 'Walk', or 'Cycle'")]
        public string EventType { get; set; } = "Run";

        /// <summary>
        /// Maximum number of participants allowed
        /// </summary>
        [Required(ErrorMessage = "Max participants is required")]
        [Range(1, 100000, ErrorMessage = "Max participants must be between 1 and 100,000")]
        public int MaxParticipants { get; set; }

        /// <summary>
        /// Event status: "Upcoming", "Ongoing", "Completed", or "Cancelled"
        /// (Optional — defaults to "Upcoming" on creation)
        /// </summary>
        [RegularExpression("^(Upcoming|Ongoing|Completed|Cancelled)$",
            ErrorMessage = "Status must be 'Upcoming', 'Ongoing', 'Completed', or 'Cancelled'")]
        public string? Status { get; set; }
    }
}