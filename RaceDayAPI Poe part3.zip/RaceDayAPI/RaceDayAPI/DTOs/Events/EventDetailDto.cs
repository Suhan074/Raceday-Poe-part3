using RaceDayAPI.DTOs.Categories;

namespace RaceDayAPI.DTOs.Events
{
    public class EventDetailDto
    {
        public int EventID { get; set; }
        public string EventName { get; set; } = string.Empty;
        public string? Description { get; set; }
        public string? BannerImageUrl { get; set; } // <-- NEW
        public DateTime EventDate { get; set; }
        public string Location { get; set; } = string.Empty;
        public string Distance { get; set; } = string.Empty;
        public string EventType { get; set; } = string.Empty;
        public int MaxParticipants { get; set; }
        public string Status { get; set; } = string.Empty;
        public string OrganiserName { get; set; } = string.Empty;
        public List<CategoryListDto> Categories { get; set; } = new List<CategoryListDto>();
    }
}