namespace RaceDayAPI.DTOs.Auth
{
    /// <summary>
    /// User information returned after successful login or registration
    /// </summary>
    public class UserInfoDto
    {
        /// <summary>
        /// Unique user ID
        /// </summary>
        public int UserID { get; set; }

        /// <summary>
        /// User's email address
        /// </summary>
        public string Email { get; set; } = string.Empty;

        /// <summary>
        /// User's full name
        /// </summary>
        public string FullName { get; set; } = string.Empty;

        /// <summary>
        /// User's role: "Organiser" or "Participant"
        /// </summary>
        public string Role { get; set; } = string.Empty;
    }
}