namespace RaceDayAPI.DTOs.Auth
{
    /// <summary>
    /// Response returned after successful login or registration
    /// Contains the JWT token and user information
    /// </summary>
    public class AuthResponseDto
    {
        /// <summary>
        /// JWT token to use for authenticated requests
        /// </summary>
        public string Token { get; set; } = string.Empty;

        /// <summary>
        /// Basic info about the logged-in user
        /// </summary>
        public UserInfoDto User { get; set; } = new UserInfoDto();
    }
}