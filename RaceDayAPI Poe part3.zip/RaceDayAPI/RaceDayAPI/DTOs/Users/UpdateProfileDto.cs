using System.ComponentModel.DataAnnotations;

namespace RaceDayAPI.DTOs.Users
{
    /// <summary>
    /// Data sent by a user to update their own profile
    /// </summary>
    public class UpdateProfileDto
    {
        /// <summary>
        /// New full name (optional)
        /// </summary>
        [MaxLength(255, ErrorMessage = "Full name cannot exceed 255 characters")]
        [MinLength(2, ErrorMessage = "Full name must be at least 2 characters")]
        public string? FullName { get; set; }

        /// <summary>
        /// New email address (optional, must be unique)
        /// </summary>
        [EmailAddress(ErrorMessage = "Invalid email format")]
        [MaxLength(255, ErrorMessage = "Email cannot exceed 255 characters")]
        public string? Email { get; set; }
    }
}