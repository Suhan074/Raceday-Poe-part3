namespace RaceDayAPI.DTOs.Users
{
    public class UserProfileDto
    {
        public int UserID { get; set; }
        public string Email { get; set; } = string.Empty;
        public string FullName { get; set; } = string.Empty;
        public string? ProfileImageUrl { get; set; } // <-- NEW
        public string Role { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
    }
}