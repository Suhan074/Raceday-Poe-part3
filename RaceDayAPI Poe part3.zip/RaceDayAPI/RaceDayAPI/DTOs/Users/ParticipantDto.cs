namespace RaceDayAPI.DTOs.Users
{
    /// <summary>
    /// Response returned when listing all participants (for Organisers)
    /// </summary>
    public class ParticipantDto
    {
        /// <summary>
        /// Unique user ID
        /// </summary>
        public int UserID { get; set; }

        /// <summary>
        /// Participant's email address
        /// </summary>
        public string Email { get; set; } = string.Empty;

        /// <summary>
        /// Participant's full name
        /// </summary>
        public string FullName { get; set; } = string.Empty;

        /// <summary>
        /// Total number of enrolments this participant has
        /// </summary>
        public int EnrolmentCount { get; set; }
    }
}