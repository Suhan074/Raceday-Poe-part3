namespace RaceDayAPI.DTOs.Users
{
    /// <summary>
    /// Response returned when listing a user's enrolments
    /// </summary>
    public class UserEnrolmentDto
    {
        /// <summary>
        /// Unique enrolment ID
        /// </summary>
        public int EnrolmentID { get; set; }

        /// <summary>
        /// Name of the event the user is enrolled in
        /// </summary>
        public string EventName { get; set; } = string.Empty;

        /// <summary>
        /// Name of the category within the event
        /// </summary>
        public string CategoryName { get; set; } = string.Empty;

        /// <summary>
        /// When the user enrolled
        /// </summary>
        public DateTime EnrolmentDate { get; set; }

        /// <summary>
        /// Enrolment status: "Pending", "Confirmed", or "Cancelled"
        /// </summary>
        public string Status { get; set; } = string.Empty;

        /// <summary>
        /// Payment status: "Pending", "Paid", or "Refunded"
        /// </summary>
        public string PaymentStatus { get; set; } = string.Empty;

        /// <summary>
        /// Whether a result has been recorded for this enrolment
        /// </summary>
        public bool HasResult { get; set; }
    }
}