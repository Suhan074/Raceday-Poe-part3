using System.ComponentModel.DataAnnotations;

namespace RaceDayAPI.DTOs.Results
{
    /// <summary>
    /// Data sent by an Organiser to create a new result for an enrolment
    /// </summary>
    public class CreateResultDto
    {
        /// <summary>
        /// ID of the enrolment the result belongs to
        /// </summary>
        [Required(ErrorMessage = "Enrolment ID is required")]
        [Range(1, int.MaxValue, ErrorMessage = "Enrolment ID must be a positive number")]
        public int EnrolmentId { get; set; }

        /// <summary>
        /// Race finish time (e.g., 03:45:20). Optional for DNS/DNF.
        /// </summary>
        public TimeSpan? FinishTime { get; set; }

        /// <summary>
        /// Final position/ranking (1 = first place). Optional.
        /// </summary>
        [Range(1, 100000, ErrorMessage = "Position must be a positive number")]
        public int? Position { get; set; }

        /// <summary>
        /// Result status: "DNS", "DNF", "Finished", or "Disqualified"
        /// </summary>
        [RegularExpression("^(DNS|DNF|Finished|Disqualified)$",
            ErrorMessage = "Status must be 'DNS', 'DNF', 'Finished', or 'Disqualified'")]
        public string? Status { get; set; }

        /// <summary>
        /// Optional notes about the result
        /// </summary>
        [MaxLength(1000, ErrorMessage = "Notes cannot exceed 1000 characters")]
        public string? Notes { get; set; }
    }
}