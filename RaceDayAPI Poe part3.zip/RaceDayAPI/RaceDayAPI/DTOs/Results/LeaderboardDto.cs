namespace RaceDayAPI.DTOs.Results
{
    /// <summary>
    /// Response returned for the public leaderboard of an event
    /// </summary>
    public class LeaderboardDto
    {
        /// <summary>
        /// Final position/ranking
        /// </summary>
        public int? Position { get; set; }

        /// <summary>
        /// Full name of the participant
        /// </summary>
        public string ParticipantName { get; set; } = string.Empty;

        /// <summary>
        /// Category the participant competed in
        /// </summary>
        public string CategoryName { get; set; } = string.Empty;

        /// <summary>
        /// Race finish time
        /// </summary>
        public TimeSpan? FinishTime { get; set; }
    }
}