namespace RaceDayAPI.DTOs.Results
{
    /// <summary>
    /// Response returned when a Participant views their own results
    /// </summary>
    public class MyResultDto
    {
        /// <summary>
        /// Unique result ID
        /// </summary>
        public int ResultID { get; set; }

        /// <summary>
        /// Name of the event
        /// </summary>
        public string EventName { get; set; } = string.Empty;

        /// <summary>
        /// Category the participant competed in
        /// </summary>
        public string CategoryName { get; set; } = string.Empty;

        /// <summary>
        /// Race finish time
        /// </summary>
        public TimeSpan? FinishTime { get; set; }

        /// <summary>
        /// Final position/ranking
        /// </summary>
        public int? Position { get; set; }

        /// <summary>
        /// Result status: "DNS", "DNF", "Finished", or "Disqualified"
        /// </summary>
        public string Status { get; set; } = string.Empty;

        /// <summary>
        /// Optional notes about the result
        /// </summary>
        public string? Notes { get; set; }
    }
}