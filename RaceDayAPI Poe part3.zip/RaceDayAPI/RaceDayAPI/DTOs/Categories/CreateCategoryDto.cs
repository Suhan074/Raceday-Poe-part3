using System.ComponentModel.DataAnnotations;

namespace RaceDayAPI.DTOs.Categories
{
    /// <summary>
    /// Data sent by an Organiser to create or update a category
    /// </summary>
    public class CreateCategoryDto
    {
        /// <summary>
        /// Name of the category (e.g., "Senior Men 10km")
        /// </summary>
        [Required(ErrorMessage = "Category name is required")]
        [MaxLength(255, ErrorMessage = "Category name cannot exceed 255 characters")]
        [MinLength(3, ErrorMessage = "Category name must be at least 3 characters")]
        public string CategoryName { get; set; } = string.Empty;

        /// <summary>
        /// Description of the category (optional)
        /// </summary>
        [MaxLength(1000, ErrorMessage = "Description cannot exceed 1000 characters")]
        public string? Description { get; set; }

        /// <summary>
        /// Minimum age allowed in this category (optional)
        /// </summary>
        [Range(0, 120, ErrorMessage = "Minimum age must be between 0 and 120")]
        public int? MinAge { get; set; }

        /// <summary>
        /// Maximum age allowed in this category (optional)
        /// </summary>
        [Range(0, 120, ErrorMessage = "Maximum age must be between 0 and 120")]
        public int? MaxAge { get; set; }

        /// <summary>
        /// Gender restriction: "None", "Male", or "Female"
        /// </summary>
        [RegularExpression("^(None|Male|Female)$",
            ErrorMessage = "Gender restriction must be 'None', 'Male', or 'Female'")]
        public string? GenderRestriction { get; set; }
    }
}