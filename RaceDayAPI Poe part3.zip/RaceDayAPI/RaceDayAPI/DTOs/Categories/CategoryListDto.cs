namespace RaceDayAPI.DTOs.Categories
{
    /// <summary>
    /// Response returned when listing categories (summary info)
    /// </summary>
    public class CategoryListDto
    {
        /// <summary>
        /// Unique category ID
        /// </summary>
        public int CategoryID { get; set; }

        /// <summary>
        /// Name of the category
        /// </summary>
        public string CategoryName { get; set; } = string.Empty;

        /// <summary>
        /// Description of the category
        /// </summary>
        public string? Description { get; set; }

        /// <summary>
        /// Minimum age allowed in this category
        /// </summary>
        public int? MinAge { get; set; }

        /// <summary>
        /// Maximum age allowed in this category
        /// </summary>
        public int? MaxAge { get; set; }

        /// <summary>
        /// Gender restriction: "None", "Male", or "Female"
        /// </summary>
        public string GenderRestriction { get; set; } = string.Empty;

        /// <summary>
        /// ID of the event this category belongs to
        /// </summary>
        public int EventID { get; set; }

        /// <summary>
        /// Name of the event this category belongs to
        /// </summary>
        public string EventName { get; set; } = string.Empty;

        /// <summary>
        /// Number of enrolments in this category
        /// </summary>
        public int EnrolmentCount { get; set; }
    }
}