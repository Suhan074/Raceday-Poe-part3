using System.ComponentModel.DataAnnotations;

namespace RaceDayAPI.DTOs.Enrolments
{
    /// <summary>
    /// Data sent by a Participant to enrol in a category
    /// </summary>
    public class CreateEnrolmentDto
    {
        /// <summary>
        /// ID of the category the participant wants to enrol in
        /// </summary>
        [Required(ErrorMessage = "Category ID is required")]
        [Range(1, int.MaxValue, ErrorMessage = "Category ID must be a positive number")]
        public int CategoryId { get; set; }
    }
}