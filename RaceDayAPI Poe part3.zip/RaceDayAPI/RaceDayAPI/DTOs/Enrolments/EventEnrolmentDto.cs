namespace RaceDayAPI.DTOs.Enrolments
{
    /// <summary>
    /// Response returned when an Organiser views all enrolments for an event
    /// </summary>
    public class EventEnrolmentDto
    {
        /// <summary>
        /// Unique enrolment ID
        /// </summary>
        public int EnrolmentID { get; set; }

        /// <summary>
        /// Full name of the participant
        /// </summary>
        public string ParticipantName { get; set; } = string.Empty;

        /// <summary>
        /// Email of the participant
        /// </summary>
        public string ParticipantEmail { get; set; } = string.Empty;

        /// <summary>
        /// Category the participant is enrolled in
        /// </summary>
        public string CategoryName { get; set; } = string.Empty;

        /// <summary>
        /// When the participant enrolled
        /// </summary>
        public DateTime EnrolmentDate { get; set; }

        /// <summary>
        /// Enrolment status: "Pending", "Confirmed", or "Cancelled"
        /// </summary>
        public string Status { get; set; } = string.Empty;

        /// <summary>
        /// Payment status: "Pending", "Paid", or "Refunded"
        /// </summary>
        public string PaymentStatus { get; set; } = string.Empty;
    }
}